# Telegram Sync Bot

A webhook bot for syncing Telegram posts with Ray's Heritage automations.